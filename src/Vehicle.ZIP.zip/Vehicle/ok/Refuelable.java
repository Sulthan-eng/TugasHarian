package Vehicle.ok;

public interface Refuelable {
    void refuel(double amount);
    boolean isFuelLow();
}
